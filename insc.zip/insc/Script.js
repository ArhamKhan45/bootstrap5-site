function open_form() {
  document.getElementById("myform").style.display = "block";
  document.getElementById("send_message_button").style.display = "none";
}
function close_form() {
  document.getElementById("myform").style.display = "none";
  document.getElementById("send_message_button").style.display = "block";
}
